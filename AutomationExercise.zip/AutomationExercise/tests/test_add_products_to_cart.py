"""
Test Case: Add Products in Cart
Steps:
1. Go to Products page.
2. Add the first product to the cart.
3. Click 'View Cart' in the popup.
4. Verify the product appears on the Cart page.
"""
from pages.products_page import ProductsPage
from pages.cart_page import CartPage


def test_add_products_to_cart(home_page):
    page = home_page.page

    # Step 1: go to Products page
    home_page.go_to_products_page()

    products_page = ProductsPage(page)

    # Step 2: add the first product to the cart (index 0 = first product)
    products_page.add_product_to_cart_by_index(0)

    # Step 3: go straight to the cart from the popup
    products_page.go_to_cart_from_popup()
    assert page.url == "https://www.automationexercise.com/view_cart"

    # Step 4: verify a product is now in the cart
    cart_page = CartPage(page)
    product_count = cart_page.get_number_of_products_in_cart()
    assert product_count >= 1
    print(f"Cart now contains {product_count} product(s)")
