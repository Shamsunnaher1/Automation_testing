"""
Test Case: Register User
Steps:
1. Go to Signup / Login page.
2. Fill name + email and click Signup.
3. Fill the account information form and submit it.
4. Verify 'ACCOUNT CREATED!' message.
5. Verify user is logged in ('Logged in as ...').
6. Clean up: delete the account so the test can be run again with a fresh email.
"""
from pages.login_page import LoginPage
from pages.account_page import AccountInformationPage, AccountCreatedPage, AccountDeletedPage
from utils.helpers import generate_unique_email, generate_random_name


def test_register_user(home_page):
    page = home_page.page

    name = generate_random_name()
    email = generate_unique_email()
    password = "Test@1234"

    # Step 1: go to Signup / Login page
    home_page.go_to_signup_login_page()

    # Step 2: fill the small signup form (reusable function)
    login_page = LoginPage(page)
    login_page.start_signup(name, email)

    # Step 3: fill the full account information form
    account_info_page = AccountInformationPage(page)
    account_info_page.fill_account_information(password=password, day="10", month="5", year="1995")
    account_info_page.fill_address_information(
        first_name=name,
        last_name="Tester",
        address="123 Test Street",
        country="United States",
        state="Texas",
        city="Austin",
        zipcode="12345",
        mobile_number="1234567890",
    )
    account_info_page.click_create_account()

    # Step 4: verify account created message
    account_created_page = AccountCreatedPage(page)
    assert account_created_page.get_confirmation_text() == "ACCOUNT CREATED!"
    print("Account created successfully")
    account_created_page.click_continue()

    # Step 5: verify user is logged in
    assert home_page.is_logged_in_as(name)
    print(f"Logged in as {name}")

    # Step 6 (cleanup): delete the account so re-running the test never clashes
    page.locator('a[href="/delete_account"]').click()
    page.wait_for_timeout(2000)
    account_deleted_page = AccountDeletedPage(page)
    assert account_deleted_page.get_confirmation_text() == "ACCOUNT DELETED!"
    print("Test account deleted (cleanup done)")
