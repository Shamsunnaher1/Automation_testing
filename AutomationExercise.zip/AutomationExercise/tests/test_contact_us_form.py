"""
Test Case: Contact Us Form
Steps:
1. Go to Contact Us page.
2. Verify 'Get In Touch' section is visible.
3. Fill name, email, subject and message, then submit the form.
4. Accept the confirmation popup.
5. Verify the success message.
"""
from pages.contact_us_page import ContactUsPage


def test_contact_us_form(home_page):
    page = home_page.page

    # Step 1: go to Contact Us page
    home_page.go_to_contact_us_page()

    contact_us_page = ContactUsPage(page)

    # Step 2: verify the section is visible
    assert contact_us_page.get_in_touch_text.is_visible()
    print("'Get In Touch' section is visible")

    # Step 3: fill and submit the form (reusable fill_form function)
    contact_us_page.fill_form(
        name="Test User",
        email="testuser@example.com",
        subject="Automation Practice",
        message="This message was sent by an automated Playwright test.",
    )
    contact_us_page.submit_form()

    # Step 4 & 5: verify success message
    success_text = contact_us_page.get_success_message()
    assert success_text == "Success! Your details have been submitted successfully."
    print("Contact Us form submitted successfully")
