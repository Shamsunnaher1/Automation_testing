"""
Test Case: Search Product
Steps:
1. Go to Products page.
2. Search for a product, e.g. 'Top'.
3. Verify 'Searched Products' heading is visible.
4. Verify that at least one product was found.
"""
from pages.products_page import ProductsPage


def test_search_product(home_page):
    page = home_page.page

    # Step 1: go to Products page
    home_page.go_to_products_page()
    assert page.url == "https://www.automationexercise.com/products"

    # Step 2: search for a product (reusable search_product function)
    products_page = ProductsPage(page)
    products_page.search_product("Top")

    # Step 3: verify heading changed to 'Searched Products'
    # NOTE: the site displays this heading in uppercase using CSS
    # (text-transform), so we compare in lowercase to ignore that.
    heading_text = products_page.searched_products_title.inner_text().lower()
    assert "searched products" in heading_text
    print("'Searched Products' heading is visible")

    # Step 4: verify results were found
    results_count = products_page.get_number_of_results()
    assert results_count > 0
    print(f"Found {results_count} product(s) matching the search")
