"""
Test Case: Verify Test Cases Page
Steps:
1. Launch browser and open the home page (done by the 'home_page' fixture).
2. Click on 'Test Cases' button in the navbar.
3. Verify that the user is navigated to the Test Cases page.
"""
from pages.test_cases_page import TestCasesPage


def test_verify_test_cases_page(home_page):
    page = home_page.page

    # Step: go to the Test Cases page using the reusable navigation function
    home_page.go_to_test_cases_page()

    # Verify URL
    assert page.url == "https://www.automationexercise.com/test_cases"
    print("Successfully navigated to the Test Cases page URL")

    # Verify page heading
    # NOTE: the site displays this heading in uppercase using CSS
    # (text-transform), so we compare in lowercase to ignore that.
    test_cases_page = TestCasesPage(page)
    assert "test cases" in test_cases_page.get_title_text().lower()
    print("Test Cases page heading is visible")
