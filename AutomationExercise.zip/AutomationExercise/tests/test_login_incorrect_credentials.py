"""
Test Case: Login User with incorrect email and password
Steps:
1. Go to Signup / Login page.
2. Enter an email and password that do not belong to any account.
3. Click Login.
4. Verify the error message 'Your email or password is incorrect!' is shown.
"""
from pages.login_page import LoginPage


def test_login_with_incorrect_credentials(home_page):
    page = home_page.page

    # Step 1: go to Signup / Login page
    home_page.go_to_signup_login_page()

    # Step 2 & 3: try logging in with an account that does not exist
    login_page = LoginPage(page)
    login_page.login(email="not_a_real_user_123@example.com", password="wrongPassword123")

    # Step 4: verify the error message
    error_text = login_page.get_login_error_text()
    assert error_text == "Your email or password is incorrect!"
    print("Correct error message shown for invalid login")
