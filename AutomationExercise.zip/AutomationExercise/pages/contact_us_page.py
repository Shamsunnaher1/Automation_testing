from playwright.sync_api import Page


class ContactUsPage:
    """Represents the 'Contact Us' page (https://www.automationexercise.com/contact_us)."""

    def __init__(self, page: Page):
        self.page = page

        self.get_in_touch_text = page.locator("h2:has-text('Get In Touch')")
        self.name_field = page.locator('input[data-qa="name"]')
        self.email_field = page.locator('input[data-qa="email"]')
        self.subject_field = page.locator('input[data-qa="subject"]')
        self.message_field = page.locator('textarea[data-qa="message"]')
        self.submit_button = page.locator('input[data-qa="submit-button"]')
        self.success_message = page.locator(".status.alert-success")
        self.home_button = page.locator("a.btn.btn-success")

    def fill_form(self, name: str, email: str, subject: str, message: str):
        """Fills every field of the Contact Us form. One function, four fields."""
        self.name_field.fill(name)
        self.email_field.fill(email)
        self.subject_field.fill(subject)
        self.message_field.fill(message)

    def submit_form(self):
        """
        Clicking Submit opens a browser confirm() popup ('Press OK to proceed').
        We tell Playwright to accept it BEFORE clicking, otherwise the click
        would get stuck waiting for the popup.
        """
        self.page.once("dialog", lambda dialog: dialog.accept())
        self.submit_button.click()
        self.page.wait_for_timeout(2000)

    def get_success_message(self) -> str:
        return self.success_message.inner_text().strip()

    def click_home_button(self):
        self.home_button.click()
        self.page.wait_for_timeout(2000)
