from playwright.sync_api import Page


class TestCasesPage:
    """Represents the 'Test Cases' page (https://www.automationexercise.com/test_cases)."""

    # Tells pytest "this is not a test class", even though its name starts
    # with 'Test' (pytest would otherwise print a harmless warning about it).
    __test__ = False

    def __init__(self, page: Page):
        self.page = page
        self.page_title = page.locator("h2.title")

    def get_title_text(self) -> str:
        return self.page_title.inner_text().strip()
