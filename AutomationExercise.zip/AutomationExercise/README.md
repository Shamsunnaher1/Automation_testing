# AutomationExercise - Playwright + Pytest (Page Object Model)

Automated tests for https://www.automationexercise.com/, built the same way
as the sample project you shared (Playwright + pytest + Page Object Model +
reusable functions for login/navigation/form filling).

## Project Structure

```
AutomationExercise/
├── conftest.py                     # shared pytest fixtures: page, home_page
├── pytest.ini
├── requirements.txt
├── pages/                          # Page Object Model - one file per page
│   ├── home_page.py                # navbar links (reusable navigation)
│   ├── login_page.py               # login() and start_signup() functions
│   ├── account_page.py             # account info / created / deleted pages
│   ├── contact_us_page.py          # fill_form() function
│   ├── products_page.py            # search_product(), add_product_to_cart_by_index()
│   ├── cart_page.py
│   └── test_cases_page.py
├── utils/
│   └── helpers.py                  # generate_unique_email(), generate_random_name()
└── tests/                          # one test case per file
    ├── test_verify_test_cases_page.py     # Test Case: Verify Test Cases Page
    ├── test_register_user.py              # Test Case: Register User
    ├── test_login_incorrect_credentials.py# Test Case: Login with incorrect credentials
    ├── test_contact_us_form.py            # Test Case: Contact Us Form
    ├── test_search_product.py             # Test Case: Search Product
    └── test_add_products_to_cart.py       # Test Case: Add Products in Cart
```

## How it follows the demo project's style

- Same fixture pattern in `conftest.py`: a `page` fixture that opens/closes the
  browser, and a second fixture (`home_page`) that opens the website and hands
  back a ready-to-use Page Object — just like `login_page` / `logged_in_page`
  did in the sample project.
- Same Page Object style: every page is a small class, locators are declared
  in `__init__`, and actions are plain methods (`login()`, `search_product()`,
  `fill_form()`...).
- Same beginner-friendly habits: `page.wait_for_timeout(...)` after actions,
  plain `assert` statements, and `print()` messages so you can follow along
  in the terminal while it runs.
- "Functional approach" for repeated steps: instead of copy-pasting the same
  steps in every test, repeated actions live in one function and every test
  simply calls it:
  - Navigation: `home_page.go_to_products_page()`, `go_to_contact_us_page()`, etc.
  - Login: `login_page.login(email, password)`
  - Form filling: `account_info_page.fill_account_information(...)`,
    `contact_us_page.fill_form(...)`

## Setup

```bash
pip install -r requirements.txt
playwright install chromium
```

## Run all tests

Run this command from inside the `AutomationExercise` folder:

```bash
pytest
```

## Run a single test

```bash
pytest tests/test_search_product.py
```

## Notes for a beginner

- `home_page.open()` is called automatically for you by the `home_page`
  fixture, so every test starts on the home page already.
- `test_register_user.py` deletes the account it creates at the end of the
  test (cleanup step), and it generates a brand-new random email every time
  (`utils/helpers.py`) so you can run it again and again without getting an
  "Email Address already exist!" error.
- The website occasionally tweaks its HTML. If a locator ever stops working,
  open the page in your browser, right-click the element → Inspect, and
  update the matching line in the relevant file inside `pages/`.
