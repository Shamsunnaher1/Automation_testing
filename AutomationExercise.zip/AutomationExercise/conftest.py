import pytest
from playwright.sync_api import sync_playwright
from pages.home_page import HomePage

# automationexercise.com shows Google ads, and sometimes a full-screen ad
# ("Vignette" ad) pops up over the page and steals whatever we try to click
# next. Blocking requests to these ad domains stops the ad from ever
# loading, so it can never get in the way of a click.
AD_DOMAINS_TO_BLOCK = [
    "**/*doubleclick.net/**",
    "**/*googlesyndication.com/**",
    "**/*googleadservices.com/**",
    "**/*google.com/pagead/**",
    "**/*google.com/ads/**",
]


@pytest.fixture
def page():
    """Opens one browser + one tab for each test, and closes it afterwards."""
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()

        # Block ad requests so no ad popup can appear during the test
        for pattern in AD_DOMAINS_TO_BLOCK:
            page.route(pattern, lambda route: route.abort())

        yield page

        browser.close()


@pytest.fixture
def home_page(page):
    """Opens the website and returns the Home Page object, ready to use."""
    home = HomePage(page)
    home.open()
    return home
